from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
import requests
import random
 
app = FastAPI()
 
BASE_IEEE_URL = "https://ieeexplore.ieee.org"
 
@app.post("/research_papers")
async def retrieve_research_papers(request: Request):
    try:
        dialogflow_request = await request.json()
        intent_display_name = dialogflow_request.get("queryResult", {}).get("intent", {}).get("displayName", "")
 
        intent_to_function = {
            "Security_and_Privacy": web_scrape_ieee,
            "Operating_systems": web_scrape_ieee,
            "Machine_learning": web_scrape_ieee,
            "Wireless_mobile_computing": web_scrape_ieee,
            "Computer_architectures": web_scrape_ieee,
            "Programming_languages": web_scrape_ieee,
            "Software_engineering": web_scrape_ieee,
            "Robotics_AI": web_scrape_ieee,
            "Natural_language_processing": web_scrape_ieee,
            "Databases": web_scrape_ieee,
            "Cloud_Computing": web_scrape_ieee,
        }
 
        if intent_display_name in intent_to_function:
            paper_data = intent_to_function[intent_display_name](intent_display_name)
            if paper_data:
                paper_data = paper_data[:5]
                response_text = format_response(intent_display_name, paper_data)
            else:
                response_text = f"No research papers found on {intent_display_name}."
        else:
            response_text = "Intent not recognized."
 
        response = {
            "fulfillmentText": response_text
        }
 
        return JSONResponse(content=response, headers={"Content-Type": "application/json"})
 
    except Exception as e:
        return JSONResponse(content={"fulfillmentText": f"An error occurred while processing the request: {str(e)}"})
 
def web_scrape_ieee(intent_name):
    try:
        # Change the search term based on the intent
        search_term = intent_name.replace('_', ' ')
 
        # Change this for different page no
        page_no = random.randint(1, 100)
 
        headers = {
            "Accept": "application/json, text/plain, */*",
            "Origin": "https://ieeexplore.ieee.org",
            "Content-Type": "application/json",
        }
        payload = {
            "newsearch": True,
            "queryText": search_term,
            "highlight": True,
            "returnFacets": ["ALL"],
            "returnType": "SEARCH",
            "pageNumber": page_no,
        }
        r = requests.post(
            "https://ieeexplore.ieee.org/rest/search",
            json=payload,
            headers=headers
        )
        page_data = r.json()
        random.shuffle(page_data["records"])
        # Extract the paper titles and links from the page_data
        paper_data = [{"title": record["articleTitle"], "link": BASE_IEEE_URL + record["documentLink"]} for record in
                      page_data["records"]]
 
        return paper_data
    except Exception as e:
        print(f"An error occurred during web scraping: {str(e)}")
        return []
 
def format_response(intent_name, paper_data):
    response_text = f"Here are some research papers on {intent_name}:\n"
    
    for idx, paper in enumerate(paper_data, start=1):
        response_text += f"{idx}) {paper['title']}\n --{paper['link']}\n\n"
    
    
    return response_text

if __name__ == "__main__":
    import uvicorn
 
    uvicorn.run(app, host="0.0.0.0", port=8000)
 